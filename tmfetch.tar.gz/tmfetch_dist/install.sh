#!/bin/bash
echo "Installing tmfetch"
if command -v doas >/dev/null 2>&1; then
    RB="doas"
elif command -v sudo >/dev/null 2>&1; then
    RB="sudo"
else
    echo "Error: Neither sudo nor doas found. Please install one or run as root."
    exit 1
fi
DIR="$(cd "$(dirname "$0")" && pwd)"
$RB chmod +x "$DIR/tmfetch" && 
$RB mv "$DIR/tmfetch" /usr/local/bin/
echo "Done!"
