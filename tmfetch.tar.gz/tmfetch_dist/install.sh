echo "Installing tmfetch..."
DIR="$(cd "$(dirname "$0")" && pwd)"
sudo chmod +x "$DIR/tmfetch" && \
sudo mv "$DIR/tmfetch" /usr/local/bin/
echo "Done!"
